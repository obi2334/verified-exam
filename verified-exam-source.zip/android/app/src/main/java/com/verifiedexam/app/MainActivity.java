package com.verifiedexam.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
